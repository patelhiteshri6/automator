package com.aaars.b;

public class TriggerLogs {
    public int id;

    public TriggerLogs() {}

    public TriggerLogs(int id) {
        this.id = id;
    }
}
